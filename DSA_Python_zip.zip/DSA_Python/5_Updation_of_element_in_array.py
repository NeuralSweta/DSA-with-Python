"""
Update element at specific position in array
"""

def update_at_position(arr, position, new_value):
    """Update element at specific position"""
    arr[position] = new_value
    return arr

# Example usage
arr = [10, 20, 30, 40, 50]
print(f"Original: {arr}")

arr = update_at_position(arr, 2, 99)
print(f"After updating position 2 to 99: {arr}")
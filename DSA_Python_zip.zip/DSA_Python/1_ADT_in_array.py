class MyArray:
    def __init__(self, total_size, used_size):
        self.total_size = total_size
        self.used_size = used_size
        self.ptr = [0] * total_size
    
    def display(self):
        print("Array elements are:", end=" ")
        for i in range(self.used_size):
            print(self.ptr[i], end=" ")
        print()  # Add newline at the end

def main():
    marks = MyArray(10, 5)  # create array
    for i in range(marks.used_size):
        marks.ptr[i] = i + 1  # set some values
    marks.display()

if __name__ == "__main__":
    main() # Array elements are: 1 2 3 4 5 
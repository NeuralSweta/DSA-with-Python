"""
Delete element by position from array
"""

def delete_by_position(arr, position):
    """Delete element by position"""
    arr.pop(position)
    return arr

# Example usage
arr = [10, 20, 30, 40, 50]
print(f"Original: {arr}")

arr = delete_by_position(arr, 2)
print(f"After deleting at position 2: {arr}")
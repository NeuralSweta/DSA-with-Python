# Memory is allocated automatically
arr = [i * 2 for i in range(5)]

# Or dynamically growing lists
my_list = []
for i in range(5):
    my_list.append(i * 2)  # Memory grows automatically

# Memory is freed automatically when arr goes out of scope
# or when there are no more references to it




# Dynamic Memory Allocation in C
# In C, you manually manage memory using functions like:

# malloc() - allocates memory
# calloc() - allocates and initializes memory to zero
# realloc() - resizes previously allocated memory
# free() - deallocates memory

# example:
# #include <stdio.h>
# #include <stdlib.h>

# int main() {
#     int *arr;
#     int size = 5;
    
#     // Allocate memory for 5 integers
#     arr = (int*)malloc(size * sizeof(int));
    
#     if (arr == NULL) {
#         printf("Memory allocation failed\n");
#         return 1;
#     }
    
#     // Use the memory
#     for (int i = 0; i < size; i++) {
#         arr[i] = i * 2;
#     }
    
#     // Must manually free the memory
#     free(arr);
#     arr = NULL; // Good practice
    
#     return 0;
# }
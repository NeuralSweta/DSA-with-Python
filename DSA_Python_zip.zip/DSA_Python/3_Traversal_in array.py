def traverse_array(arr):
    """Traverse array using index"""
    print(f"Array: {arr}")
    for i in range(len(arr)):
        print(f"Index {i}: {arr[i]}")

# Example usage
numbers = [10, 25, 33, 47, 52]
traverse_array(numbers)
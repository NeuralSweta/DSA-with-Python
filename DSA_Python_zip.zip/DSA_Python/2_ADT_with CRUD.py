class MyArray:
    def __init__(self, total_size):
        self.total_size = total_size
        self.used_size = 0
        self.ptr = [0] * total_size
    
    def create(self, elements):
        """Create array with given elements"""
        if len(elements) > self.total_size:
            print("Error: Too many elements for array size!")
            return False
        
        for i, element in enumerate(elements):
            self.ptr[i] = element
        self.used_size = len(elements)
        print(f"Array created with {self.used_size} elements")
        return True
    
    def insert(self, index, value):
        """Insert element at specific index"""
        if self.used_size >= self.total_size:
            print("Error: Array is full!")
            return False
        
        if index < 0 or index > self.used_size:
            print("Error: Invalid index!")
            return False
        
        # Shift elements to right
        for i in range(self.used_size, index, -1):
            self.ptr[i] = self.ptr[i-1]
        
        self.ptr[index] = value
        self.used_size += 1
        print(f"Inserted {value} at index {index}")
        return True
    
    def append(self, value):
        """Add element at the end"""
        return self.insert(self.used_size, value)
    
    def update(self, index, new_value):
        """Update element at specific index"""
        if index < 0 or index >= self.used_size:
            print("Error: Invalid index!")
            return False
        
        old_value = self.ptr[index]
        self.ptr[index] = new_value
        print(f"Updated index {index}: {old_value} -> {new_value}")
        return True
    
    def delete(self, index):
        """Delete element at specific index"""
        if index < 0 or index >= self.used_size:
            print("Error: Invalid index!")
            return False
        
        deleted_value = self.ptr[index]
        
        # Shift elements to left
        for i in range(index, self.used_size - 1):
            self.ptr[i] = self.ptr[i + 1]
        
        self.used_size -= 1
        print(f"Deleted {deleted_value} from index {index}")
        return True
    
    def search(self, value):
        """Search for a value and return its index"""
        for i in range(self.used_size):
            if self.ptr[i] == value:
                return i
        return -1
    
    def display(self):
        """Display all array elements"""
        if self.used_size == 0:
            print("Array is empty")
            return
        
        print("Array elements are:", end=" ")
        for i in range(self.used_size):
            print(self.ptr[i], end=" ")
        print(f"\nUsed: {self.used_size}/{self.total_size}")
    
    def is_full(self):
        """Check if array is full"""
        return self.used_size == self.total_size
    
    def is_empty(self):
        """Check if array is empty"""
        return self.used_size == 0

def show_menu():
    print("\n=== Array Operations Menu ===")
    print("1. Create array with elements")
    print("2. Insert element at index")
    print("3. Append element at end")
    print("4. Update element")
    print("5. Delete element")
    print("6. Search element")
    print("7. Display array")
    print("8. Check if full/empty")
    print("9. Exit")
    print("=" * 30)

def main():
    print("Welcome to Dynamic Array Operations!")
    
    # Get array size from user
    total_size = int(input("Enter total size of array: "))
    arr = MyArray(total_size)
    
    while True:
        show_menu()
        
        try:
            choice = int(input("Enter your choice (1-9): "))
            
            if choice == 1:
                # Create array
                elements_str = input("Enter elements separated by spaces: ")
                if elements_str.strip():
                    elements = list(map(int, elements_str.split()))
                    arr.create(elements)
                else:
                    arr.create([])
            
            elif choice == 2:
                # Insert at index
                index = int(input("Enter index to insert at: "))
                value = int(input("Enter value to insert: "))
                arr.insert(index, value)
            
            elif choice == 3:
                # Append at end
                value = int(input("Enter value to append: "))
                arr.append(value)
            
            elif choice == 4:
                # Update element
                index = int(input("Enter index to update: "))
                new_value = int(input("Enter new value: "))
                arr.update(index, new_value)
            
            elif choice == 5:
                # Delete element
                index = int(input("Enter index to delete: "))
                arr.delete(index)
            
            elif choice == 6:
                # Search element
                value = int(input("Enter value to search: "))
                index = arr.search(value)
                if index != -1:
                    print(f"Found {value} at index {index}")
                else:
                    print(f"{value} not found in array")
            
            elif choice == 7:
                # Display array
                arr.display()
            
            elif choice == 8:
                # Check status
                if arr.is_empty():
                    print("Array is empty")
                elif arr.is_full():
                    print("Array is full")
                else:
                    print(f"Array has {arr.used_size} elements, {arr.total_size - arr.used_size} spaces left")
            
            elif choice == 9:
                print("Thank you for using Array Operations!")
                break
            
            else:
                print("Invalid choice! Please enter 1-9")
                
        except ValueError:
            print("Invalid input! Please enter valid numbers")
        except Exception as e:
            print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
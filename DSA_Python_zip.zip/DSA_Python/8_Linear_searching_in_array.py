def linear_search(arr, target):
    """Returns index of target or -1 if not found"""
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1

def linear_search_all(arr, target):
    """Returns all indices of target"""
    return [i for i in range(len(arr)) if arr[i] == target]

# Examples
if __name__ == "__main__":
    arr = [64, 34, 25, 12, 22, 11, 90, 25]
    
    # Basic search
    print(f"22 at index: {linear_search(arr, 22)}")      # Output: 4
    print(f"99 at index: {linear_search(arr, 99)}")      # Output: -1
    
    # Find all occurrences  
    print(f"25 at indices: {linear_search_all(arr, 25)}")  # Output: [2, 7]
    
    # Works with strings
    fruits = ["apple", "banana", "cherry"]
    print(f"banana at: {linear_search(fruits, 'banana')}") 
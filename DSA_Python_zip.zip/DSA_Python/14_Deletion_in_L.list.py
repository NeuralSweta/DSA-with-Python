class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
    
    def add(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
    
    # 1. Delete first node
    def delete_first(self):
        if self.head:
            self.head = self.head.next
    
    # 2. Delete node in between
    def delete_middle(self, pos):
        current = self.head
        for i in range(pos - 1):
            current = current.next
        current.next = current.next.next
    
    # 3. Delete last node
    def delete_last(self):
        current = self.head
        while current.next.next:
            current = current.next
        current.next = None
    
    # 4. Delete node with given value
    def delete_value(self, target):
        if self.head.data == target:
            self.head = self.head.next
            return
        current = self.head
        while current.next:
            if current.next.data == target:
                current.next = current.next.next
                return
            current = current.next
    
    # 5. Delete node after given node
    def delete_after_node(self, target):
        current = self.head
        while current:
            if current.data == target and current.next:
                current.next = current.next.next
                return
            current = current.next
    
    def display(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

# Usage showing all 5 deletion points
ll = LinkedList()
for i in [10, 20, 30, 40, 50]:
    ll.add(i)

ll.display()              # 10 -> 20 -> 30 -> 40 -> 50 -> None
ll.delete_after_node(20)  # Delete node after 20 (deletes 30)
ll.display()              # 10 -> 20 -> 40 -> 50 -> None
ll.delete_first()         # Delete first node
ll.delete_middle(1)       # Delete node in between
ll.delete_last()          # Delete last node  
ll.delete_value(20)       # Delete node with given value
ll.display()              # None
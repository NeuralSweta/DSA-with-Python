def binary_search(arr, target):
    """Returns index of target or -1 if not found"""
    left = 0
    right = len(arr) - 1
    
    while left <= right:
        mid = (left + right) // 2
        
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    
    return -1

# Example
arr = [11, 12, 22, 25, 34, 64, 90]  # Must be sorted
print(binary_search(arr, 64))  # Output: 5
print(binary_search(arr, 99))  # Output: -1
"""
Insert element at specific position in array
"""

def insert_at_position(arr, position, element):
    """Insert element at specific position"""
    arr.insert(position, element)
    return arr

# Example usage
arr = [10, 20, 30, 40]
print(f"Original: {arr}")

arr = insert_at_position(arr, 2, 25)
print(f"After inserting 25 at position 2: {arr}")